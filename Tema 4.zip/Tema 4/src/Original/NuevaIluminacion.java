package Original;

//Se importan las librerias necesarias
import com.sun.opengl.util.Animator;
import com.sun.opengl.util.GLUT;
import java.awt.Frame;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class NuevaIluminacion extends JFrame {
    
    //Matrices de los parametros de iluminacion
    final float[] mat_ambiente = {0.2f, 0.2f, 0.2f, 1.0f};
    final float[] mat_difuso = {0.8f, 0.8f, 0.8f, 1.0f};
    final float[] mat_especular = {0.0f, 0.0f, 0.0f, 1.0f};
    final float[] mat_brillo = {20.0f};
 
    public NuevaIluminacion() {
      //Titulo del Frame
      setTitle("Iluminacion y color");
      //Tama�o del Frame
      setSize(640, 480);
      //Instanciamos la clase Iluminacion
      Iluminacion listener = new  Iluminacion();
        //Creamos el canvas
        GLCanvas canvas = new GLCanvas(new GLCapabilities());
        canvas.addGLEventListener(listener);
        getContentPane().add(canvas);
        //Se crea la animacion
        final Animator animator = new Animator(canvas);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new Thread(new Runnable() {
                    public void run() {
                        animator.stop();
                        System.exit(0);
                    }}).start();
            }});
        //Localizacion del Frame
        setLocationRelativeTo(null);
        animator.start();
    }
    
    //Metodo Main
    public static void main (String args[]){
        //Instanciamos la clase
        NuevaIluminacion frame = new NuevaIluminacion();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    //Clase Iluminacion
    public class Iluminacion implements GLEventListener {
        
        //Metodo init
        public void init(GLAutoDrawable drawable) {
        GL gl = drawable.getGL(); // inicializa la variable GL

        //Se establece el color de fondo
        gl.glClearColor(0.5f, 0.5f, 1.0f, 0.0f);

        // Parametros de la luz 0
        float[] luzAmbiente = {0.1f, 0.1f, 0.1f, 1.0f};
        float[] luzDifusa = {1.0f, 1.0f, 1.0f, 1.0f};
        float[] luzEspecular = {0.0f, 0.0f, 0.0f, 1.0f};
        float[] posicion = {1.0f, 0.5f, -0.5f, 1.0f};

        // Se setean los par�metros del ambiente
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_AMBIENT, luzAmbiente, 0);
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_DIFFUSE, luzDifusa, 0);
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_SPECULAR, luzEspecular, 0);
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, posicion, 0);

        gl.glEnable(GL.GL_DEPTH_TEST); // Habilita el ocultamiento de superficies
        gl.glEnable(GL.GL_LIGHTING); // Habilita la iluminacion
        gl.glEnable(GL.GL_LIGHT0); // Habilita la luz 0 que previamente se habia seteado
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL gl = drawable.getGL();// inicializa la variable GL
        GLU glu = new GLU();// inicializa la variable GLU

        if (height == 0) { //evita un error de divisi�n por cero
            height = 1;
        }
        //Tama�o final de la ventana en la que se visualiza la imagen
        gl.glViewport(0, 0, width, height);
        //Matriz de proyeccion
        gl.glMatrixMode(GL.GL_PROJECTION);
        //Inicializa la matriz actual
        gl.glLoadIdentity();
        //Matriz de proyeccion que define una vista simetrica y multiplica por la matriz actual
        if (width > height) {
            glu.gluPerspective(45.0f, width / height, 1, 150.0f);
        } else {
            glu.gluPerspective(45.0f, width / height, 1, 150.0f);
        }
        //Matriz de modelo y vista
        gl.glMatrixMode(GL.GL_MODELVIEW);
        //Inicializa la matriz actual
        gl.glLoadIdentity();
    }

    public void display(GLAutoDrawable drawable) {
        
        //Instanciamos las variables de GLUT
        GL gl = drawable.getGL();
        GLU glu = new GLU();
        GLUT glut = new GLUT();

        // borra buffer y el z-buffer, rota el cubo y dibuja, intercambiando buffers
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        //
        gl.glLoadIdentity();

        glu.gluLookAt(1.0f, 1.0f, 3.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);//Funcion de la camara
        //            posX, posY, posZ, MiraX,miraY,miraZ,arriX,ArriY,ArriZ

        // Superficie                Parametros del objeto
        gl.glMaterialfv(GL.GL_LEFT, GL.GL_AMBIENT, mat_ambiente, 0);//Luz Ambiente
        gl.glMaterialfv(GL.GL_LEFT, GL.GL_DIFFUSE, mat_difuso, 0);//Luz Difusa
        gl.glMaterialfv(GL.GL_LEFT, GL.GL_SPECULAR, mat_especular, 0);//Luz Espectacular
        gl.glMaterialfv(GL.GL_LEFT, GL.GL_SHININESS, mat_brillo,0);//Brillo
        gl.glPushMatrix();
        
        //Lados del cubo
        // LADO FRONTAL
        gl.glBegin(GL.GL_POLYGON);
        gl.glVertex3f(0.5f, 0.5f, -0.5f);       
        gl.glVertex3f(0.5f, 0.5f, -0.5f);     
        gl.glVertex3f(-0.5f, 0.5f, -0.5f);     
        gl.glVertex3f(-0.5f, -0.5f, -0.5f);
        
        gl.glEnd();
        
        // LADO TRASERO
        gl.glBegin(GL.GL_POLYGON);
        gl.glVertex3f(0.5f, -0.5f, 0.5f);
        gl.glVertex3f(0.5f, 0.5f, 0.5f);
        gl.glVertex3f(-0.5f, 0.5f, 0.5f);
        gl.glVertex3f(-0.5f, -0.5f, 0.5f);
        gl.glEnd();

        // LADO DERECHO
        gl.glBegin(GL.GL_POLYGON);
        gl.glVertex3f(0.5f, -0.5f, -0.5f);
        gl.glVertex3f(0.5f, 0.5f, -0.5f);
        gl.glVertex3f(0.5f,  0.5f, 0.5f);
        gl.glVertex3f(0.5f, -0.5f, 0.5f);
        gl.glEnd();

        // LADO IZQUIERDO
        gl.glBegin(GL.GL_POLYGON);
        gl.glVertex3f(-0.5f, -0.5f, 0.5f);
        gl.glVertex3f( -0.5f, 0.5f, 0.5f);
        gl.glVertex3f( -0.5f, 0.5f, -0.5f);
        gl.glVertex3f( -0.5f, -0.5f, -0.5f);
        gl.glEnd();
        // LADO SUPERIOR
        gl.glBegin(GL.GL_POLYGON);
        gl.glVertex3f(0.5f, 0.5f, 0.5f);
        gl.glVertex3f(0.5f, 0.5f, -0.5f);
        gl.glVertex3f(-0.5f, 0.5f, -0.5f);
        gl.glVertex3f(-0.5f, 0.5f, 0.5f);
        gl.glEnd();
        // LADO INFERIOR
        gl.glBegin(GL.GL_POLYGON);
        gl.glVertex3f(0.5f, -0.5f, -0.5f);
        gl.glVertex3f(0.5f, -0.5f, 0.5f);
        gl.glVertex3f(-0.5f, -0.5f, 0.5f);
        gl.glVertex3f(-0.5f, -0.5f, -0.5f);
        gl.glEnd();

        //Deshabilitamos la creacion de los lados
        gl.glPopMatrix();
        drawable.swapBuffers();
        gl.glFlush();
    }

    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {
    }
    }

}