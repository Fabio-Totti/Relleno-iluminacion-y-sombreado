package Relleno;
//Se importan las librerias necesarias
import com.sun.opengl.util.Animator;
import com.sun.opengl.util.GLUT;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;

public class NuevoRelleno implements GLEventListener {
    public static void main(String[] args) {
        //Intanciamos la ventana y se nombre
        Frame frame = new Frame("Relleno Y Color");
        //Creamos el canvas
        GLCanvas canvas = new GLCanvas();
        canvas.addGLEventListener(new NuevoRelleno());
        frame.add(canvas);
        frame.setSize(640, 480);
        //Se crea la animacion
        final Animator animator = new Animator(canvas);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new Thread(new Runnable() {
                    public void run() {
                        animator.stop();
                        System.exit(0);
                    }
                }).start();
            }
        });
        //Centra la ventana en el medio de la pantalla
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        animator.start();
    }

    public void init(GLAutoDrawable drawable) {
        GL gl = drawable.getGL(); // inicializa la variable GL

        gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        gl.glShadeModel(GL.GL_SMOOTH);

    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL gl = drawable.getGL();// inicializa la variable GL
        GLU glu = new GLU();// inicializa la variable GLU

        //evita un error de divisi�n por cero
        if (height == 0) {
            height = 1;
        }
        final float h = (float) width / (float) height;
        //Determinan el tama�o final de la ventana en la que se visualiza la imagen
        gl.glViewport(0, 0, width, height);
        //GL_PROJECTION: Matriz de proyecci�n
        gl.glMatrixMode(GL.GL_PROJECTION);
        //Inicializa la matriz actual, con los valores de la matriz identidad 4*4
        gl.glLoadIdentity();
        //Matriz de proyecci�n que define una vista sim�trica y la multiplica por la matriz actual
        glu.gluPerspective(45.0f, h, 1.0, 20.0);
        //trasladar la proyeccion
        gl.glTranslated(0, -1, -10);
        //Matriz de modelo y vista
        gl.glMatrixMode(GL.GL_MODELVIEW);
        //Inicializa la matriz actual, con los valores de la matriz identidad 4*4
        gl.glLoadIdentity();
    }

    public void display(GLAutoDrawable drawable) {
        //Instanciamos las variables de GLUT
        GL gl = drawable.getGL();// inicializa la variable GL
        GLU glu = new GLU();// inicializa la variable GLU

        // borra buffer y el z-buffer, rota el cubo y dibuja, intercambiando buffers
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        gl.glLoadIdentity();//restablecer la matriz actual a la identidad
        
        //Dibujar lados del cubo
        //Abajo
        gl.glBegin(GL.GL_POLYGON);
            gl.glColor3f(0.0f, 1.0f, 1.0f);// Color
            gl.glVertex3f(-3.0f, 0.0f, -2.0f);
            gl.glVertex3f(0.0f, 1.0f, -4.0f);
            gl.glVertex3f(3.0f, 0.0f, -2.0f);
            gl.glVertex3f(0.0f, -1.0f, 0.0f);
        gl.glEnd();
        //Frontal
        gl.glBegin(GL.GL_POLYGON);
            gl.glColor3f(1.0f, 0.0f, 1.0f);//Color
            gl.glVertex3f(-3.0f, 3.0f, -2.0f); 
            gl.glVertex3f(0.0f, 4.0f, -4.0f); 
            gl.glVertex3f(0.0f, 1.0f, -4.0f);
            gl.glVertex3f(-3.0f, 0.0f, -2.0f);
        gl.glEnd();
        //Trasero
        gl.glBegin(GL.GL_POLYGON);
            gl.glColor3f(1.0f, 1.0f, 0.0f);//Color
            gl.glVertex3f(0.0f, 4.0f, -4.0f);  
            gl.glVertex3f(3.0f, 3.0f, -2.0f);  
            gl.glVertex3f(3.0f, 0.0f, -2.0f); 
            gl.glVertex3f(0.0f, 1.0f, -4.0f); 
        gl.glEnd();
        //Derecha
        gl.glBegin(GL.GL_POLYGON);
            gl.glColor3f(0.0f, 0.0f, 1.0f);//Color
            gl.glVertex3f(0.0f, 2.0f, 0.0f);  
            gl.glVertex3f(3.0f, 3.0f, -2.0f);  
            gl.glVertex3f(3.0f, 0.0f, -2.0f);  
            gl.glVertex3f(0.0f, -1.0f, 0.0f);
        gl.glEnd();
        //Izquierda
        gl.glBegin(GL.GL_POLYGON);
            gl.glColor3f(1.0f, 0.0f, 0.0f);//Color
            gl.glVertex3f(-3.0f, 3.0f, -2.0f);
            gl.glVertex3f(0.0f, 2.0f, 0.0f); 
            gl.glVertex3f(0.0f, -1.0f, 0.0f);  
            gl.glVertex3f(-3.0f, 0.0f, -2.0f); 
        gl.glEnd();
        //Superior
        gl.glBegin(GL.GL_POLYGON);
            gl.glColor3f(0.0f, 1.0f, 0.0f);//Color
            gl.glVertex3f(0.0f, 4.0f, -4.0f);
            gl.glVertex3f(3.0f, 3.0f, -2.0f); 
            gl.glVertex3f(0.0f, 2.0f, 0.0f); 
            gl.glVertex3f(-3.0f, 3.0f, -2.0f); 
        gl.glEnd();
        //Deshabilitamos la creacion de los lados
        gl.glFlush();
    }

    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {
    }
}

